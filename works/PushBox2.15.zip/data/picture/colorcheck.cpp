//this programme is used to check the number of the color

#include	<iostream>
#include	<windows.h>
#include	"../datafile/_sys_run.cpp"


int main(){
	using namespace std;
	int num;	//number
	int max;	//max
	
	int x,
		y;
	
	
	cout<<"the max=?"<<endl;
	cin>>max;
	

	
	for(num=0;num<=max;num++){
		
		_go(num,1);
		_color(15);//white
		cout<<num;
		
		_go(num,2);
		_color(num);
		cout<<"��";
		
	}
	
	return 0;
} 
