#ifndef _light_cpp
#define _light_cpp

void _light::_turn_on(const int& x,const int& y){
	_position new_position;
	new_position._set(x,y);
	_turn_on(new_position);
}
void _light::_turn_on(const _position& new_position) {
	position =new_position ;
	_wwt(position,"light",1);
}
//to switch to light mode

std::string _light::_move(const std::string& command) {
	
	key=tolower(getch());

	if(		command==	"flash"	&&	key==	'f'	
		||	command==	"eat"	&&	key==	'e'
		||	command==	"edit"	&&	key==	'f'	){
		
		_wwt(position,"light",0);
		//conveal the light
		if		/*edit==1	||	*///old version(2.14-)
			(command==	"edit"	)	return "end";
		
		if(command=="flash"){
			if( /*!position._compare(hero.position ) &&	*///(2.14-)
				_wrd(position,"hero")==0	){
				//moveable
			
				_wwt(hero.position,"hero",0);
				_wwt(position,"hero",2);
				hero.position=position; 
				
				hero.max_flash	--;
				_go(map.x,2);_color(11);
				std::cout<<" Flash= "<<hero.max_flash<<Ful_cover;
			}
			
		}
		else if(command=="eat"){
		/*
			hero.max_eat	--;
			_go(map.x,3);_color(11);
			std::cout<<" eat= "<<hero.max_eat<<Ful_cover;
		*///unfinished
		}
		//to flash to another place
		//cant eat box now(2.10+)
		
		return "end";
	}
	//end the movemont
	
	
	if(/*edit==1||	*///old version(2.14-)
		command==	"edit"){
		//edit map mode
			
		if(key=='m'){
			inum++;
			if(inum==Max_thing)	inum=0;
			for(;thing[inum].full==0 || thing[inum].light==1;inum++)
				if(inum==Max_thing-1)	inum=-1;
			
			_witem(inum);
//			_go(1,map.y);std::cout<<inum<<std::endl;//debug
		}
		//goto latter thing
		else if(key=='b'){
			inum--;
			if(inum==	-1)	inum=Max_thing-1;
			for(;thing[inum].full==0 || thing[inum].light==1;inum--)
				if(inum==	-1)	inum=Max_thing-1;
			
			_witem(inum);
//			_go(1,map.y);std::cout<<inum<<std::endl;//debug
		}
		//goto former thing
		else if(key=='n'){
			
			total_flag=	total_flag	+	thing[inum].flag	-thing[_wrd(position)].flag;
			_wwt(position,inum);
			_wdata("flag");
			
		}
		//put
		
	}
	//command expect usual movement
	
	
	_position new_position=	position;
	if(	new_position._leap(key)==1){
		return "nogo";
	}
	
	if(new_position._boundary() == 0){
		
		_wwt(position,"light",0);
		_wwt(new_position,"light",1);
		position=	new_position;
	
	}
	
	return "go";
}


#endif
