//////////	Push Box @����/@΢���� 
//////////	δ�������������ó�Ϯ�˴���
//////////	Ȼ����
//////////	chara is my waifu
#ifndef PushBox_cpp
#define PushBox_cpp
#include "PushBox.hpp"

using namespace std;


int _thing_set(){
	if (freopen("picture\\picture.txt","r",stdin)==NULL) {
		_go(0,0);cout<<"picture error";
		getch();
		return 1;
		//check error
	}

	for(int i=0;i<Max_thing;i++)
		thing[i].full=0;
	//reset all the things' set-con

	while(scanf("%d",&inum)==1){
		if (inum>=0 && inum<Max_thing) {
			cin	>>	thing[inum].color
				>>	thing[inum].show
				>>	thing[inum].hero
				>>	thing[inum].flag
				>>	thing[inum].light
				>>	thing[inum].name;

			thing[inum].full=1;
			//exist
		}
	}

	fclose(stdin);
	return 0;
}
//set all the things from "picture.txt" to Class thing

int _thing_search(const _wall& wall){
	for (int i=0;i<Max_thing;i++)
		if (		thing[i].hero  	==	wall.hero
			&& 	thing[i].flag  	==	wall.flag
			&& 	thing[i].light	==	wall.light )
			return i;

	return -1;
	//not find
}
//search the num of the thing

//	-------------------------------------------------------------------set special chars

int _move_check(const _position& position,const int& power){

	if (_wrd(position,"hero") == 0)	
		return 1;//movable
	if (_wrd(position,"hero") == 1)	
		return 0;//unmobable

	if (_wrd(position,"hero") == 3) {
		//meet the box
		if (power<=hero.max_power) {
			_position new_position	=position;
			new_position._leap(key);

			if (_move_check(new_position,power+1)) {
				if (_wrd(new_position,"flag")==1)
					total_flag--;
				if (_wrd(position,"flag")==1 )
					total_flag++;
				_wwt(new_position,"hero",3);

				_go(map.x,3);_color(11);
				cout<<" Flags= "<<total_flag<<Ful_cover;
				return 1;

			}
		}
	}

	return 0;
}
//check whether player's position is legal;
//return 1 as movable,0 as unmovable

bool _win_check(){

	if (total_flag==0) {
		_go(0,map.y+1);
		_color(10);
		std::cout<<"You Win!";
		getch();
		return 1;//win
	}
	return 0;//not win
}
//check whether player has won

//	-------------------------------------------------------------------check

int main(){

	system("chcp 936>nul.");
	_light(0);
	_thing_set();
	map.name	=	Name_map;
//	light.edit=0;//2.14-

	for(;;){
		title_show._show();
		key =tolower(getch());

		for(map._value_set(1);freopen(map.name.c_str(),"r",stdin)!=NULL;map._next());
		map.end =	map.value ;

		if(key=='n'){
			system("cls");
			_go(0,0);_color(11);//blue
			cout<<"ѡ���޸Ĺؿ�----"<<endl;
			freopen("CON","r",stdin);
			cin>>inum ;
			fclose(stdin);

//			light.edit=1;	2.14-
			if(inum<map.end){
				map._value_set(inum);
				for(map._set()	,light._turn_on(1,1)	,_witem(0);
					light._move("edit") !="end";
					);
			}
			//edit old map

			else{
				map._value_set(map.end);
				for(map._new()	,light._turn_on(1,1)	,_witem(0);
					light._move("edit") !="end";
					);
			}
			//set a new map

			map._write(map.value);
			continue;
		}
		//set map mode

		map._value_set(1);
//		light.edit=0;	2.14-

		if(key=='/'){
			system("cls");
			_go(0,0);_color(14);//yellow
			cout<<"ѡ��ؿ�----"<<endl;

			freopen("CON","r",stdin);
			cin>>inum ;

			if(inum	>=	map.end){
				cout<<"�������еĵ�ͼ����"<<endl;
				getch();
			}

			map._value_set(inum);
			//readin the stage number
			fclose(stdin);

		}
		//select the map

		for(;map.value < map.end && require!="title";map._next()){

			map._set();

			for(;	!_win_check() 	;){
				require =hero._move() ;

				if(require=="title"){
					map.value =	1;
					//prevent presious win
					break;
				}
				//go back to title
				else if(require	==	"reset"){
					map._set() ;
				}
				//reset
				else if(require	==	"flash"){
					for(light._turn_on(hero.position) ;light._move("flash") !="end";);
				}
				//flash
				else if(require	==	"pass"){
					break;
				}
				//pass
				else if(require =="eat"){
					for(light._turn_on(hero.position)	;	light._move("eat") !="end"	;light.position=hero.position);
				}
				//eat//unfinished

				//aboves are special require

			}
		}
		//normal play mode

		require="again";
		//when the second time to start the game
	}
	//this for ensures ablility to go back to title

	return 0;
}
//	-------------------------------------------------------------------main

#endif
