#ifndef	_wall_cpp
#define	_wall_cpp
int _wall::_conclusion(const std::string& func){
	if(func	=="down"){
		//to change each floor
		hero=	thing[num].hero;
		flag=	thing[num].flag;
		light=	thing[num].light;
		
		return 0;//safe
	}
	if(func	=="up"){
		//to change the num
		for(int i=0;i<Max_thing;i++)
			if(		thing[i].hero  	==	hero  
				&& 	thing[i].flag  	==	flag 
				&& 	thing[i].light	==	light ){
				num=	i;
				return i;//safe
			}
		return -2;//not find
	}
	
	
	return -1;//the func is illegal
}
//to change the wall's num or each floor

#endif
