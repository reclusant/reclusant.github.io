#ifndef _map_cpp
#define _map_cpp

#include <sstream>
void _map::_rename(){
	std::string new_time;
			
	std::stringstream stream;
	stream<<value;
	stream>>new_time;
	//value(int)	-->	new_time(string)
	
	name.replace(7,time.length(),new_time);
	time=new_time;
}
//rename the map

int _map::_set(){

	system("cls");
	total_flag=0;
	note="";
	//reset
	
	using namespace std;
	if( value	>=	end ){
		return 0;//end
	}
	//if all maps being covered,end the game
	
	freopen(map.name.c_str(),"r",stdin);
	scanf("max_power=%d\n"	,	&hero.max_power );
	scanf("max_flash=%d\n"	,	&hero.max_flash );
//	scanf("max_eat=%d\n"	,	&hero.max_eat	);
	scanf("max_x=%d\n",&x );
	scanf("max_y=%d\n",&y );
	
	//read in the basic data	
	
	for(light.position._set(-1,0) ;light.position._scan()==0;){
		cin>>inum;
		
		_wwt(light.position,"num"	,inum);
		_wwt(light.position,"hero"	,thing[inum].hero);
		_wwt(light.position,"flag"	,thing[inum].flag);
		_wwt(light.position,"light"	,thing[inum].light);
		
		if(_wrd(light.position,"hero")	==	2){
			//here is hero
			hero.position=	light.position;
		}
		if(_wrd(light.position,"flag")	==1	&&	_wrd(light.position,"hero")	!=3){
			//here is flag
			total_flag++;
		}
		
	}
	//read and write the map
		
	/*
	if(light.edit==1){
		light._turn_on(1,1);
		inum=0;
		_pri(map.x,map.y,inum);
		cout<<thing[inum].name<<Ful_cover;
	}
	*///2.14-
	
	_basic_data();
	
	return 1;
}
//set the next map

int _map::_new(){
	
	using	namespace	std;
	system("cls");
	freopen("CON","r",stdin);
	_color(11);//blue
	cout<<"�½���ͼ------"<<endl;
	cout<<"�����ͼ�ĳ���"<<endl;
	cin>>x ;
	cout<<"�����ͼ�Ŀ���"<<endl;
	cin>>y ; 
	cout<<"�������������"<<endl;
	cin>>hero.max_power;
	cout<<"�������ִ�����"<<endl;
	cin>>hero.max_flash; 
	
	total_flag	=	0;
	//cin basic data
	
	system("cls");
	fclose(stdin);
//	_go(x,y);cout<<total<<endl;getch();//debug
	
	for(light.position._set(-1,0); light.position._scan()==0 ;){
		if(light.position._boundary() ==1)
			_wwt(light.position,1);
		else
			_wwt(light.position,0);
	}
	//set an empty map
	
	_basic_data();
	//set a new wall
	
	/*
	light._turn_on(1,1);
	inum=0;
	_pri(map.x,map.y,inum);
	cout<<thing[inum].name<<Ful_cover;
	*/
	
	title_show._tutoriel("edit");
	
	return 0;
} 
//set a new map

int _map::_next(){
	value	++;
	_rename();
	return value;
}
//find the next map

void _map::_value_set(const int& number){
	value =	number;
	_rename();
}
//set the value

void _map::_basic_data(){
	using namespace std;
	/*
	_go(x,0);
	_color(11);//blue
	cout<<" Stage= "<<value<<Ful_cover;
	_go(x,1);
	cout<<" Power= "<<hero.max_power<<Ful_cover;
	_go(x,2);
	cout<<" Flash= "<<hero.max_flash<<Ful_cover;
	_go(x,3);
	cout<<" Flags= "<<total_flag<<Ful_cover;
	*///2.14-
	
	_wdata("stage"	);
	_wdata("power"	);	
	_wdata("flash"	);
	_wdata("flag"	);
	
}
//write the basic data of this map

int _map::_write(const int& new_value){
	using namespace std;
	
	_value_set(new_value);
	
	_go(0,y);cout<<"��ǰ��ͼ��"<<value<<endl;
	cout<<"�˳�������Ӧ������"<<endl;
	
	//follows are in bugs
	
	if(	freopen(name.c_str(),"w",stdout)==NULL){
		cout<<"error write"<<endl;
	}
	
	cout<<"max_power="<<hero.max_power<<endl;
	cout<<"max_flash="<<hero.max_flash<<endl;
	cout<<"max_x="<<x<<endl;
	cout<<"max_y="<<y<<endl;
	//write the basic data
	
	for (int i=0; i<map.y; i++) {
		for(int j=0;j<map.x;j++){
			cout<<wall[i][j]._conclusion("up")<<" ";
		}
		cout<<endl;
	}
	
	if (value >= end)	end++;
	
	if (freopen("CON","w",stdout) == NULL){
		cout<<"error rewrite"<<endl;
	}
	
	getch();
	return 0;
}
//write the map in a new txt

#endif
