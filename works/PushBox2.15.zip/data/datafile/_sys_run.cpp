#ifndef _sys_run_cpp
#define _sys_run_cpp
void _light(const bool& light){
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);  
	CONSOLE_CURSOR_INFO CursorInfo;  
	GetConsoleCursorInfo(handle, &CursorInfo); 
	CursorInfo.bVisible = light; 
	SetConsoleCursorInfo(handle, &CursorInfo);
}
void _go(const int& x,const int& y){
	COORD pos;
	pos.X=2*x;
	pos.Y=y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),pos);
}
void _color(const int& color){
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),color);
}
#endif
