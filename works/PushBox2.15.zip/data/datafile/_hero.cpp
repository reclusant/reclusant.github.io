

#ifndef _hero_cpp
#define _hero_cpp

std::string _hero::_move(){
	
	
	key=tolower(getch());
	
//	_go(map.x+8,map.y+8);std::cout<<"aaaaaaa"<<" "<<key<<Ful_cover;//debug
	
	if(key=='r'){
		return "reset";
	}
	//reset the map
	
	if(key=='t'){
		return "title";
	}
	//return to title
	
	if(key=='f'){
		if(max_flash >0){
			return "flash";
		}
	}
	//call out the light,to flash into another place--
	//can eat box and wall now(2.00+)
	//cant eat box and wall now(2.10+)
	
	if(key=='e'){
		return "eat";
	}
	//eat the box/wall
	//unfinished(2.10+)
	
	if(key==	'p'){
		return "pass";
	}
	//pass to the next stage
	
	_position new_position	=	position;
//	new_position=	position;
	if(	new_position._leap(key)==1){
		return "nogo";
	}
	
	if( _move_check(new_position,1)	==	1 ){	
		_wwt(position,"hero",0);
		_wwt(new_position,"hero",2);
		position=	new_position;
	} 
	return "go";
}

#endif
