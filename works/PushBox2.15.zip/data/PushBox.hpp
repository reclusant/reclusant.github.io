#ifndef	PushBox_hpp
#define PushBox_hpp
//poor english
#include <iostream>
#include <windows.h>
#include <conio.h>
#include <string.h>
//////headfile

const int Max_map				=	50;
//the max of the length and width of the map in each stage
const int Max_thing				=	50;
//the amount of the kind of things(in "picture.txt")
const std::string Name_map		=	"map\\map.txt";
//the name of our maps
const std::string Ful_cover	=	"              ";
//to cover the whole prints

//////const

class _position{
	public:
		int x,y;
		//as position
		
		int _set(const int& newx,const int& newy);
		//set the position
		int _leap(const char& direction);
		//to the next position
		int _compare(const _position& new_posiiton);
		//compare two positions
		//return 1 as the same,0 as different
		int _boundary();
		//check whether reach the boundary
		//return 1 as yes,0 as no
		int _scan();
		//to scan the whole map
};
//save a position

class _hero{
	public:
		_position position;
		
		int max_power;
		//the max amount of boxs to be pushable
		int max_flash;
		//the max times to flash into another place
		int max_eat;
		//the max times to eat the box
		
		std::string _move();
		//move the position
};
//control the hero

class _light{
	public:
		_position position;
		
//		int edit;
//		whether in edit mode//2.14-
		
		void _turn_on(const int& x,const int& y);
		void _turn_on(const _position& new_position);
		//to switch to light mode
		std::string _move(const std::string& command);
		//move the position
};
//show the light

class _map{
	public:
		int x,y;
		//x	=	length
		//y	=	width
		std::string name;
		//full address
		std::string	time,	note;
		//time	=	address number in string
		//note	=	note for the map(poor english)(unavailable now)
		int value;
		//address number in int
		int end;
		//the end number of the maps(end is empty)
		
		int _set();
		//set the next map
		void _rename();
		//rename the map
		int _new();
		//set a new map
		int _next();
		//find the next map
		void _value_set(const int& number);
		//set the first map(onlu valuie)
		void _basic_data();
		//write the basic data of this map
		int _write(const int& new_value);
		//write the map in a new txt
};
//read and control each map

class _thing{
	public:
		int full;
		//whether this char has been set
		int color;
		//the color of the char
		std::string	
			show,	
			name;
		//show	=	the char shown on the screen
		//name	=	the name to mark each thing
		int 
			hero,
			flag,
			light;
		//please read "rules.txt"
		
};
//special chars

class _title_show{
	public:
		int x,y,z;
		
		void _e(int num);
		//easily show a line of char
		void _show();
		//to show the title
		int _tutoriel(std::string name);
		//to show the tutoriel
		
};
//show the title

class _wall{
	public:
		
		int num;
		//num	=	the number of thing in this position
		int hero;
		//hero	=	the situation about hero floor
		int flag;
		//flag	=	the situation about flag floor
		int light;
		//light	=	the situation about light floor
		
		int _conclusion(const std::string& func);
		//to change the wall's num or each floor
		
};
//background

//////class

int	inum;
//input num
char key;
//input key
int total_flag;
//amout of flags
std::string require;
//special requirements
////var for alllll

_thing thing[Max_thing];
_map map;
_title_show title_show;
_hero hero;
_wall wall[Max_map][Max_map];
_light light;
//////var

void _light(const bool& light);
//change the color of the mouse
void _go(const int& x,const int& y);
//change the positon of the light
void _color(const int& color);
//change the color of the next char
////_sys_run.cpp

int _thing_set();
//set all the things from "picture.txt" to Class thing
int _thing_search(const _wall& wall);
//search the num of the thing
////

void _out(const int& num);
void _out(const _wall& wall);
//print out the char in its color
void _pri(const _position& position);
void _pri(const int& x,const int& y);
//read the wall and print the char in the exact position
void _pri(const _position& position,const int& num);
void _pri(const int& x,const int& y,const int& num);
//use the exact char and print the char in the exact position
int _wwt(const _position& position,const int& num);
int _wwt(const _position& position,const std::string& floor,const int& num);
//change the wall and print out
int _wrd(const _position& position);
int _wrd(const _position& position,const std::string& floor);
//read the wall at exact floor
int _wdata(const std::string& data);
//writhe the basic data nearby
int _witem(const int& num);
//write the selected item nearby
////_pri.cpp

int _move_check(const _position& position,const int& power);
//check whether player's position is legal;
//return 1 as movable,0 as unmovable

bool _win_check();
//check whether player has won

//////function
#include "datafile\\_hero.cpp"
#include "datafile\\_light.cpp"
#include "datafile\\_map.cpp"
#include "datafile\\_position.cpp"
#include "datafile\\_pri.cpp"
#include "datafile\\_sys_run.cpp"
#include "datafile\\_title_show.cpp"
#include "datafile\\_wall.cpp"

#endif
