#ifndef _pri_cpp
#define _pri_cpp

void _out(const int& num){
	using namespace std;
	
	if(thing[num].full){
		_color(thing[num].color);
		cout<<thing[num].show;
	}
	else	cout<<"? ";//error
}
void _out(const _wall& wall){
	_out(_thing_search(wall));
}
//print out the char in its color

void _pri(const _position& position){
	_go(position.x,position.y);
	_out( _thing_search(wall[position.y][position.x])	);
}
void _pri(const int& x,const int& y){
	_go(x,y);
	_out( wall[y][x]);
}
//read the wall and print the char in the exact position
void _pri(const _position& position,const int& num){
	_go(position.x,position.y);
	_out(num);
}
void _pri(const int& x,const int& y,const int& num){
	_go(x,y);
	_out(num);
}
//use the exact char and print the char in the exact position

int _wwt(const _position& position,const int& num){
	return _wwt(position,"num",num);
}
int _wwt(const _position& position,const std::string& floor,const int& num){
	
	if(floor	==	"num"){
		wall[position.y ][position.x ].num		=	num;
		wall[position.y ][position.x ]._conclusion("down");
	}
	if(floor	==	"hero"){
		wall[position.y ][position.x ].hero		=	num;
	}
	if(floor	==	"flag"	){
		wall[position.y ][position.x ].flag		=	num;
	}
	if(floor	==	"light"){
		wall[position.y ][position.x ].light	=	num;
	}
	
	_pri(position);
	
	return 0;
}
//change the wall and print out
int _wrd(const _position& position){
	return _wrd(position,"num");
}

int _wrd(const _position& position,const std::string& floor){
	if(floor	==	"num"){
		return	wall[position.y ][position.x ].num	;
	}
	if(floor	==	"hero"){
		return	wall[position.y ][position.x ].hero	;
	}
	if(floor	==	"flag"	){
		return	wall[position.y ][position.x ].flag	;
	}
	if(floor	==	"light"){
		return	wall[position.y ][position.x ].light;
	}
	
	return -1;//error
}
//read the wall at exact floor

int _wdata(const std::string& data){
	using namespace std;
	_color(11);//blue
	if(data	==	"stage"){
		_go(map.x,0);
		cout<<" Stage= "<<map.value<<Ful_cover;
	}
	else if(data	==	"power"){
		_go(map.x,1);
		cout<<" Power= "<<hero.max_power<<Ful_cover;
	}
	else if(data	==	"flash"){
		_go(map.x,2);
		cout<<" Flash= "<<hero.max_flash<<Ful_cover;
	}
	else if(data	==	"flag"){
		_go(map.x,3);
		cout<<" Flags= "<<total_flag<<Ful_cover;
	}
	else{
		return -1;
		//illegal
	}
	
	return 0;
}
//writhe the basic data nearby

int _witem(const int& num){
	
	if(	num>=Max_thing	||
		thing[num].full==0){
		//this thing dont exist 
		return -1;	
	}
	
	_pri(map.x,map.y,num);
	std::cout<<thing[num].name<<Ful_cover;
	
	return 0;
	
}
//write the selected item nearby

//	-------------------------------------------------------------------pri special chars

#endif
