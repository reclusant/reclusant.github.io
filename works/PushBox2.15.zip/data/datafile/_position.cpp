#ifndef _position_cpp
#define _position_cpp
//this file is about class _position

int _position::_set(const int& newx,const int& newy){
	x=newx;
	y=newy;
	return 1;//safe
}
//set the position

int _position::_leap(const char& direction){
	
	switch(direction){
		case 'w':y--;break;
		case 's':y++;break;
		case 'a':x--;break;
		case 'd':x++;break;
		//usual leap	
		default: return 1;//derection is illegal
	}
	
	return 0;//safe
}
//to the next position
//return 1 as illegal

int _position::_compare(const _position& new_position){
	if(new_position.x == x && new_position.y == y){
		return 1;
	}
	return 0;
}
//compare two positions
//return 1 as the same,0 as different

int _position::_boundary(){
	if(x == 0 ||	y == 0 ||	x == map.x-1 ||	y == map.y-1){
		return 1;
	}
	return 0;
}
//check whether reach the boundary
//return 1 as yes,0 as no

int _position::_scan(){
	x++;
	if(x>=map.x ){
		x=0;
		y++;
		if( y>=map.y ){
			return 1;//load to end
		}
	}
	return 0;
}
//to scan the whole map

#endif
